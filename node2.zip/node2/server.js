const express = require("express");
const path = require('path');

const app = express();
const PORT = 3000;

app.use(express.json());
app.use(express.static('public'))

const produtosRoutes = require('./src/routes/produtosRoutes');
app.use('/api/produtos',produtosRoutes);

app.get('/',(req,res)=>{
    res.sendFile(path.join(__dirname, 'public,', 'index.html'));
});

app.listen(PORT, () =>{
    console.log(`Servidor rodando em http://localhost:${PORT}`);
});