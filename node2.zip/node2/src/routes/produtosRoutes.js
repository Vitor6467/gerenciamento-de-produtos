const express = require('express');
const router = express.Router();

const produtosController = require('../controllers/produtosController');

router.get('/',produtosController.listar);
router.get('/:id',produtosController.buscarPorId);
router.post('/', produtosController.criar);
router.put('/',produtosController.atualizar);
router.delete('/',produtosController.deletar);

module.exports = router;