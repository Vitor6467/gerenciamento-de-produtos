const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('./database.db',(err) =>{
    if(err){
        console.error('Erro ao conectar banco', err);
    }else{
        console.log('Banco conectado com sucesso!')
    }
});


db.run(`
    CREATE TABLE IF NOT EXISTS Produtos(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nome TEXT NOT null,
        preco REAL NOT NULL
    )
`);

module.exports = db;
