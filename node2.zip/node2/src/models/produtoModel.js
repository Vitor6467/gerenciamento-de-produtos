const db = require('../database/conexao');

module.exports = {
    listarTodos() {
        return new Promise((resolve, reject) => {
            db.all("SELECT * FROM produtos", [], (err, rows) => {
                if (err) reject(err);
                else resolve(rows);
            });
        });
    },

    buscarPorId(id) {
        return new Promise((resolve, reject) => {
            db.get("SELECT * FROM produtos WHERE id = ?", [id], (err, row) => {
                if (err) reject(err);
                else resolve(row);
            });
        });
    },

    criar(nome, preco) {
        return new Promise((resolve, reject) => {
            const query = "INSERT INTO produtos (nome, preco) VALUES (?, ?)";
            db.run(query, [nome, preco], function (err) {
                if (err) reject(err);
                else resolve({ id: this.lastID, nome, preco });
            });
        });
    },

    atualizar(id, nome, preco) {
        return new Promise((resolve, reject) => {
            const query = "UPDATE produtos SET nome = ?, preco = ? WHERE id = ?";
            db.run(query, [nome, preco, id], function (err) {
                if (err) {
                    reject(err);
                } else {
                    resolve({ id, nome, preco });
                }
            });
        });
    },

    deletar(id) {
        return new Promise((resolve, reject) => {
            const query = "DELETE FROM produtos WHERE id = ?";
            db.run(query, [id], function (err) {
                if (err) {
                    reject(err);
                } else {
                    resolve(this.changes > 0); 
                }
            });
        });
    }
};
