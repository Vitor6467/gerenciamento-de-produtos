const Produto = require('../models/produtoModel');


module.exports = {
    async listar(req,res){
        try{
            const produtos = await Produto.listarTodos();
            res.json(produtos);
        }catch (erro) {
            res.status(500).json({erro: 'Produto não encontrado'})
        }
    },

    async buscarPorId(req,res){
        try{
            const id= req.parms.id;
            const produtos = await Produto.buscarPorId(id);

            if(!produto){
                return res.status(404).json({erro: "Produto não encontrado"});
            }
            res.json(produtos);
        }catch (erro) {
            res.status(500).json({erro: 'Erro ao buscar produto'})
        }
    },

    async criar(req, res){
        try{
            const{nome, preco} = req.body;
            if(!nome || !preco){
                return res.status(404).json({erro: "Nome e preço são obrigatorios"});
            }
            const novo = await Produto.criar(nome, preco);
            res.status(201).json({mensagem: "Produto criado!", id: novo.id});
        }catch(erro){
            res.status(500).json({erro: "Erro ao criar produto"});
        }
    },

    async atualizar(req, res){
        try{
            const id = req.parms.id;
            const {nome, preco} = req.body;

            const atualizado = await Produto.atualizar(id, nome, preco);

            if(!atualizado){
                return res.status(404).json({erro: "Produto não encontrado"});
            }
            res.json({mensagem: "Produto atualizado!"});
        }catch(erro){
            res.status(505).json({erro: "Erro ao atualizar o produto"});
        }
    },

    async deletar(req, res){
        try{
            const id = req.parms.id;
            
            const deletado = await Produto.deletar(id);

            if(!deletado){
                return res.status(404).json({erro: "Produto não encontrado"});
            }
            res.json({mensagem: "Produto Deletado"});

        }catch(erro){
            res.status(505).json({erro: "Erro ao deletar produto"});
        }
    },




}