const tabela = document.getElementById("tabela-produtos");
const form = document.getElementById("form");
const nomeInput = document.getElementById("nome");
const precoInput = document.getElementById("preco");

let editandoId = null;

carregarProdutos();

async function carregarProdutos() {
    const resp = await fetch("/api/produtos");
    const dados = await resp.json();

    tabela.innerHTML = "";

    dados.forEach(produto => {
        tabela.innerHTML += `
            <tr>
                <td>${produto.id}</td>
                <td>${produto.nome}</td>
                <td>${produto.preco}</td>
                <td>
                    <button class="editar" onclick="editarProduto(${produto.id}, '${produto.nome}', ${produto.preco})">Editar</button>
                    <button class="deletar" onclick="deletarProduto(${produto.id})">Excluir</button>
                </td>
            </tr>
        `;
    });
}

function editarProduto(id){
    editandoId = id;
    nomeInput.value = nome;
    precoInput.value = preco;
}

async function deletarProduto(id) {
    await fetch(`/api/produtos/${id}`, {method: "DELETE"});
    carregarProdutos();
}

form.addEventListener("submit", async (e) => {
    e.preventDefault();

    const nome = nomeInput.value;
    const preco = precoInput.value;

    // Modo edição
    if (editandoId) {
        await fetch(`/api/produtos/${editandoId}`, {
            method: "PUT",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({ nome, preco })
        });
        editandoId = null;
    } 
    else {
        // Criar novo
        await fetch("/api/produtos", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({ nome, preco })
        });
    }

    form.reset();
    carregarProdutos();
});

// Função editar
function editarProduto(id, nome, preco) {
    editandoId = id;
    nomeInput.value = nome;
    precoInput.value = preco;
}
